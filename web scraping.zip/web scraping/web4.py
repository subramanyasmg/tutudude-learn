
import requests

user = {
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
}

params = {
    "offset": "10"
}

url = "http://localhost:8000/post/"
response = requests.get(url, params=params)
print(response.text)
